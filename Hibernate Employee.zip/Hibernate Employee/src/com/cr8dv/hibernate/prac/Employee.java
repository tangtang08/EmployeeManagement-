package com.cr8dv.hibernate.prac;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table(name="employee_details")

public class Employee {

	@Id 
	@Column(name="id")
	private int id;
	
	@Column(name="FirstName")
	private String FirstName;
	
	@Column(name="LastName")
	private String LastName;
	
	@Column(name="Department")
	private String Department;
	
	@Column(name="StartDate")
	private int StartDate;
	
	@Column(name="PayRate")
	private int PayRate;
	
	@Column(name="NumberOfDaysPresent")
	private int NumberOfDaysPresent;
	
	@Column(name="TotalSalaryForThisMonth")
	private int TotalSalaryForThisMonth;
	
	@Column(name="Hours")
	private int Hours;
	
	@Column(name="Status")
	private String Status;	
	
	
	//public static void main(String[] args) {

	//}

	//you must have a default constructor AND a parameterized constructors
	public Employee (){
		
	}
	
	public Employee(String FirstName, String LastName, String Department, int StartDate, 
			int PayRate, int NumberOfDaysPresent,int TotalSalaryForThisMonth, int Hours, String Status ){
			
			this.FirstName= FirstName;
			this.LastName= LastName;
			this.Department=Department;
			this.StartDate=StartDate;
			this.PayRate= PayRate;
			this.NumberOfDaysPresent=NumberOfDaysPresent;
			this.TotalSalaryForThisMonth=TotalSalaryForThisMonth;
			this.Hours=Hours;
			this.Status=Status;		
		
	}
	
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getFirstName() {
		return FirstName;
	}


	public void setFirstName(String FirstName) {
		this.FirstName = FirstName;
	}

	public String getLastName() {
		return LastName;
	}


	public void setLastName(String LastName) {
		this.LastName = LastName;
	}


	public String getDepartment() {
		return Department;
	}


	public void setDepartment(String Department) {
		this.Department = Department;
	}


	public int getStartDate() {
		return StartDate;
	}


	public void setStartDate(int StartDate) {
		this.StartDate = StartDate;
	}

	public int getPayRate() {
		return PayRate;
	}

	public void setPayRate(int PayRate) {
		this.PayRate = PayRate;
	}


	public int getNumberOfDaysPresent() {
		return NumberOfDaysPresent;
	}


	public void setNumberOfDaysPresent(int NumberOfDaysPresent) {
		this.NumberOfDaysPresent = NumberOfDaysPresent;
	}


	public int TotalSalaryForThisMonth() {
		return TotalSalaryForThisMonth;
	}


	public void TotalSalaryForThisMonth(int TotalSalaryForThisMonth) {
		this.TotalSalaryForThisMonth = TotalSalaryForThisMonth;
	}


	public int getHours() {
		return Hours;
	}


	public void setHours(int Hours) {
		this.Hours = Hours;
	}


	public String getStatus() {
		return Status;
	}


	public void setStatus(String Status) {
		this.Status= Status;
	}



@Override 
public String toString (){
	
	return "[Employee Id=" + id + " , First Name =" + FirstName + ",Last Name=" + LastName +", Department"
			+ Department + ",Start Date" + StartDate + ",Pay Rate" + PayRate + ", Number of Days present" 
			+ NumberOfDaysPresent + ", Total Salary for this month"+ TotalSalaryForThisMonth + ", Hours"+ Hours + ",Status" + Status + "]";
}
}
