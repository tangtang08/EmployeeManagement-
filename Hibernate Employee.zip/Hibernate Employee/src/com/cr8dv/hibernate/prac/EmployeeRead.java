package com.cr8dv.hibernate.prac;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cr8dv.hibernate.prac.Employee;

public class EmployeeRead {

	public static void main(String[] args) {
		//create session factory 
		
				SessionFactory fact = new Configuration()
											.configure("hibernate.cfg.xml")
											.addAnnotatedClass(Employee.class)
											.buildSessionFactory();
				//create session
				Session session = fact.getCurrentSession();
				
						try{
							
				//start a transaction
							session.beginTransaction();
							
							Employee Employee = session.get(Employee.class, 1);
							
							System.out.println("Value printed for first row first  name " + Employee.getFirstName());
							System.out.println("Value printed for first row last name " + Employee.getLastName());
							System.out.println("Value printed for first row email " + Employee.getDepartment());
							System.out.println("Value printed for first row first  name " + Employee.getStartDate());
							System.out.println("Value printed for first row last name " + Employee.getPayRate());
							System.out.println("Value printed for first row email " + Employee.getNumberOfDaysPresent());
							System.out.println("Value printed for first row first  name " + Employee.TotalSalaryForThisMonth());
							System.out.println("Value printed for first row last name " + Employee.getHours());
							System.out.println("Value printed for first row email " + Employee.getStatus());
							
							 
							//commit transaction 
							
							session.getTransaction().commit();
							
							System.out.println("done");
							
						}
									finally{
										fact.close();
									}

			}

			

	}

