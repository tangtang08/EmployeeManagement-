package com.cr8dv.hibernate.prac;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class ActualApp {
	String  firstName, lastName, department, Status;
	int startDate, payRate, daysPresent, monthSalary, hours;
	static	Scanner keyboard = new Scanner(System.in);

	public static void main(String[] args) {
		

		//create session factory
		SessionFactory factory = new Configuration()				
				.configure("hibernate.cfg.xml")				
				.addAnnotatedClass(Employee.class)
				.buildSessionFactory();
	
		//create session
		Session session= factory.getCurrentSession();
		
		try{
			
			//the logic goes here
			System.out.println("First Name");
			String FirstName= keyboard.nextLine(); 
			System.out.println(FirstName);
			
			System.out.println("Last Name");
			String LastName=keyboard.nextLine();
			System.out.println(LastName);
			
			System.out.println("Department");
			String Department=keyboard.nextLine();
			System.out.println(Department);
			
			System.out.println("Start Date");
			int StartDate=keyboard.nextInt();
			System.out.println(StartDate);
			
			System.out.println("Pay Rate");
			int PayRate=keyboard.nextInt();
			System.out.println(PayRate);
			
			System.out.println("Days Present");
			int NumberOfDaysPresent=keyboard.nextInt();
			System.out.println(NumberOfDaysPresent);
			
			System.out.println("Monthly Salary");
			int TotalSalaryForThisMonth=keyboard.nextInt();
			System.out.println(TotalSalaryForThisMonth);
			
			System.out.println(" hours");
			int Hours=keyboard.nextInt();
			System.out.println(Hours);
			
			System.out.println("Status");
			String Status=keyboard.nextLine();
			System.out.println(Status);
			
			
//create a employee object
			
			Employee theEmployee = new Employee ( FirstName, LastName, Department, StartDate, PayRate,NumberOfDaysPresent, TotalSalaryForThisMonth, Hours, Status);
		
					
		 //start transaction
		 session.beginTransaction();
		 
		 // save the employee object
		 session.save(theEmployee);
		 
		 //commit transaction
		 session.getTransaction().commit();
		
	}
		
	
	finally {
		factory.close();
	}
	}

}
